package g5.hangestfinal;

public class StandardThings {


}
